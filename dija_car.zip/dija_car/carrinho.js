const botao = document.getElementById('carrinho')
const botao2 = document.getElementById('caminhao2')
const fechar = document.getElementById('fechar')
const btn_finalizar = document.getElementById('finalizar_compra')
const menu_carrinho = document.getElementById('menu_carrinho')

botao.addEventListener('click', abrir)
botao2.addEventListener('click', abrir)
fechar.addEventListener('click', abrir)
btn_finalizar.addEventListener('click', abrir)

function abrir(){
    menu_carrinho.classList.toggle('active')
    botao.classList.toggle('active')
    const fechar = document.getElementById('fechar')
    fechar.addEventListener('click', fechar)
}

arrayCarrinho = []

lista_carro = [
    { id: 1, nome: 'GM ONIX SEDAN | 2022/2022', preco: 81580.01},
    { id: 2, nome: 'GM ONIX HATCH | 2019/2020', preco: 79999.01},
    { id: 3, nome: 'GM CRUZE | 2019/2020', preco: 147790.99 },
    { id: 4, nome: 'RENAULT KWID | 2018/2018', preco: 65790.01},
    { id: 5, nome: 'GM BLAZER | 2020/2020 ', preco: 379620.01},
    { id: 6, nome: 'HONDA HR-V | 2020/2021 ', preco: 140999.99},
    { id: 7, nome: 'GM BLAZER | 2020/2021 ', preco: 300000.00},
]

function comprarItem(id) {
    alert("Item adicionado ao carrinho ☺")
    var valorTotal = 0
    var prod = lista_carro.find(x => x.id == id)
    arrayCarrinho.push({ nome: prod.nome, preco: prod.preco, total: valorTotal, id:prod.id})
    salvarCarrinho()
    exibirProdutos()
}

function exibirProdutos() {
    var codHTML = ''
    var valorTotal = 0
    var contador = 0;
    arrayCarrinho.forEach(prod => {
        
        codHTML += `<div class="carrinho_informacao"><b>${prod.nome}</b><b> R$ ${prod.preco}</b> &nbsp <a href="javascript:void(0)" onclick="excluir_item(${contador})"><img src="img/x.png"></a></div></br>
        <style>
            .carrinho_informacao{color:white; font-size:26px;}
            b{padding: 10px}
        </style>`
        contador ++;
        valorTotal += prod.preco
    });
    codHTML += `<h2 class="carrinho">Total: R$ ${valorTotal.toFixed(2)}
        <style>
        h2{color:white; font-size:32px; padding:10px; text-align:right; display:flex;}
        </style>`
    document.getElementById('carrinho_itens').innerHTML = codHTML
}

function salvarCarrinho() {
    localStorage.setItem('carro', JSON.stringify(arrayCarrinho))
}

function obterCarrinho() {
    if (localStorage.getItem('carro') != null) {
        arrayCarrinho = JSON.parse(localStorage.getItem('carro'))
        exibirProdutos()
    }
}

function finalizar() {
    alert('compra finalizada com sucesso!!')
    arrayCarrinho = []
    salvarCarrinho()
}

function excluir_item(contador) {
    alert("Item exluído...")
    arrayCarrinho.splice(contador, 1)
    salvarCarrinho()
    obterCarrinho()
}

obterCarrinho()
