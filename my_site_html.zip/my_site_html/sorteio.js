function sortear(){
    let lista_nomes = ['Radija', 'Agatha', 'Ayla', 'Shirley', 'Joel']
    let sorteando = lista_nomes[Math.floor(Math.random() * lista_nomes.length)]
    
    alert(sorteando)

    var $teste = document.querySelector(".teste")

    HTMLTemporario = $teste.innerHTML,

    HTMLNovo

}